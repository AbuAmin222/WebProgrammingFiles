<!DOCTYPE html>
<html>

<head>
    <title>PHP Syntax</title>
</head>

<body>
    <?php

$x =5;

    echo "Welcome to PHP"."<br>";
    echo "<h2>Welcome to PHP</h2>"."<br>";
    echo 'Welcome to PHP'."<br>";

    echo "x = $x"."<br>";
    echo 'x = $x'."<br>";

    echo 'x = '.$x."<br>";

    ECHO("aaaa")."<br>";

    echo print("AAA");

    //single-line comment
    #single-line comment

    /**dsfsdf
     * sdf
     * dsf
     * ds
     * fsd
     * f
     * sdf
     * sd
     * f
     * dsf
     * 
     */
    ?>
</body>

</html>