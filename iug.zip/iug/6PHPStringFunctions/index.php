<?php

//space
//;
//,
//.
///
//\
//*
//_
//+
//<
//>

$s = "Welcome to PHP";

echo strlen($s);
echo "<br>";
echo str_word_count($s);
echo "<br>";
echo strrev($s);
echo "<br>";
echo strpos($s,"pHP");