<!DOCTYPE html>
<html>
    <head>
        <title>Login Page</title>
    </head>

    <body>

    <form method="POST" action="home.php">
        <label>Name: </label>
        <input type="text" name="username" required/>
        <br>
        <label>Password: </label>
        <input type="password" name="password" required/>
        <br>
        <input type="submit" value="Login"/>
    </form>
    </body>
</html>