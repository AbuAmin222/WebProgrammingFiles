<!DOCTYPE html>
<html>
    <head>
        <title>Get Method</title>
    </head>

    <body>

    <a href="home.php?id=3&name=Ahmad">Click Here</a>
    </body>
</html>