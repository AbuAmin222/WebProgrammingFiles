<?php

$id = $_GET['id'];

if($id==3){
    echo $id;
    echo $_GET['name'];
}else
echo "Error";
