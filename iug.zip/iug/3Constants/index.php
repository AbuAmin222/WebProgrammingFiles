<?php

define("x","Welcome to PHP",true);
echo x;
//echo X;

